p(G) :- G = _:_.
%%%%%%%%%%%%%%%%
:- meta_predicate p(:).
p(G) :- G = _:_.
