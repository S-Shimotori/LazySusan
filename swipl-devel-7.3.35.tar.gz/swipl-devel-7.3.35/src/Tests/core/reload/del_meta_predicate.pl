:- meta_predicate p(:).
p(G) :- G = _:_.
%%%%%%%%%%%%%%%%
p(G) :- G = _:_.
