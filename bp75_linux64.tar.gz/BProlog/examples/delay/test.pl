go:-
    q(X),
    (var(X)->r(X);s(X)).
