%------------------------------------------------------------
%   File   : array.pl
%   Author : Neng-Fa ZHOU
%   Date   : 20000
%   Purpose: A library of built-ins for two-dimentional arrays
%------------------------------------------------------------
/*  NOTICE: Compound terms are used to represent arrays. Some systems cannot
    handle big arrays due to the limitation on lengths of compound terms. In 
    B-Prolog, the maximum arity is 2^16, which should not be sufficient for 
    most applications.

    create_array(+N,+M,?A)
    array_create(+N,+M,?A)
        Create a N*M array A. The indexes for the array elements go from [1,1] to [N,M]

    array_get(+I,+J,+A,?Elm)
        Elm is the element located at A[I,J]

    array_row(+I,+A,?Row)
        Row is a list of elements on the Ith row.

    array_rows(+A,?Rows)
        Rows is a list of rows (i.e., list of lists) of the array A.

    array_column(+J,+A,?Col)
        Col is a list of elements on the Jth column.

    array_columns(+A,?Cols)
        Cols is a list of columns of the array A.

    array_diagonal_up(+K,+A,?Diag):- 
       Diag is a list of elements on the left-up diagonal A[I,J] where I+J=K.

    array_diagonal_down(+K,+A,?Diag):- 
       Diag is a list of elements on the left-down diagonal A[I,J] where I-J=K.

    for_each_row(+A,+Pred)
       Apply Pred to every row of A.

    for_each_column(+A,+Pred)
       Apply Pred to every column of A.

    for_each_diagonal(+A,+Pred)
       Apply Pred to every diagonal (both up and down).

    for_each_diagonal_up(+A,+Pred)
       Apply Pred to every left-up diagonal.

    for_each_diagonal_up(+A,+Pred)
       Apply Pred to every left-down diagonal.

    array_to_list(+A,?List)
       List is a list of all the elements in the array A.

    array_labeling(+A)
       equivalent to array_to_list(A,List),labeling(List)
*/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
array_create(N,M,A):-
    create_array(N,M,A).

create_array(N,M,A):-
    functor(A,array,N),
    create_array2(N,M,A).

create_array2(I,M,A):-I=:=0,!.
create_array2(I,M,A):-
    arg(I,A,Elm),
    functor(Elm,array,M),
    I1 is I-1,
    create_array2(I1,M,A).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
array_row(I,A,Row):-
    arg(I,A,Elm),
    Elm=..[_|Row].

array_column(J,A,Col):-
    functor(A,_,N),
    array_column(1,N,J,A,Col).

array_column(N0,N,J,A,Col):-N0>N,!,Col=[].
array_column(N0,N,J,A,Col):-
    arg(N0,A,Array),
    arg(J,Array,Elm),
    Col=[Elm|ColRest],
    N1 is N0+1,
    array_column(N1,N,J,A,ColRest).

array_diagonal_up(K,A,Diag):- %I+J = K
    functor(A,_,N),
    arg(1,A,Row),
    functor(Row,_,M),
    (N=:=M-> array_diagonal_up(K,1,N,A,Diag);
     handle_exception(array_of_different_dimensions,(N,M))).
			       

array_diagonal_up(K,I0,I,A,Diag):-I0>I,!,Diag=[].
array_diagonal_up(K,I0,I,A,Diag):-
    J is K-I0,
    (J>=1,J=<I -> array_get(I0,J,A,Elm),Diag=[Elm|Diag1];
     Diag1=Diag),
    I1 is I0+1,
    array_diagonal_up(K,I1,I,A,Diag1).

array_diagonal_down(K,A,Diag):- %I-J=K
    functor(A,_,N),
    arg(1,A,Row),
    functor(Row,_,M),
    (M=:=N->array_diagonal_down(K,1,N,A,Diag);
     handle_exception(array_of_different_dimensions,(N,M))).

array_diagonal_down(K,I0,I,A,Diag):-I0>I,!,Diag=[].
array_diagonal_down(K,I0,I,A,Diag):-
    J is I0-K,
    (J>=1,J=<I -> array_get(I0,J,A,Elm),Diag=[Elm|Diag1];
     Diag1=Diag),
    I1 is I0+1,
    array_diagonal_down(K,I1,I,A,Diag1).
    
array_get(I,J,A,Elm):-
    functor(A,_,N),
    arg(1,A,Row),
    functor(Row,_,M),
    I>=1, I=<N,
    J>=1, J=<M,!,
    arg(I,A,RowI),
    arg(J,RowI,Elm).
array_get(I,J,A,Elm):-
    handle_exception(illegal_arguments,array_get(I,J,_,Elm)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
array_rows(A,Rows):-
    functor(A,_,N),
    array_rows(1,N,A,Rows).

array_rows(I0,I,A,Rows):-I0>I,!,Rows=[].
array_rows(I0,I,A,Rows):-
    array_row(I0,A,Row),
    Rows=[Row|RowsR],
    I1 is I0+1,
    array_rows(I1,I,A,RowsR).

array_columns(A,Columns):-
    arg(1,A,Row),
    functor(Row,_,M),
    array_columns(1,M,A,Columns).

array_columns(I0,I,A,Columns):-I0>I,!,Columns=[].
array_columns(I0,I,A,Columns):-
    array_column(I0,A,Column),
    Columns=[Column|ColumnsR],
    I1 is I0+1,
    array_columns(I1,I,A,ColumnsR).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for_each_row(A,Pred):-
    for_each_line(A,Pred).

for_each_line(A,Pred):-
    functor(A,_,N),
    for_each_line(1,N,A,Pred).

for_each_line(N0,N,A,Pred):-N0>N,!.
for_each_line(N0,N,A,Pred):-
    array_row(N0,A,Row),
    Call=..[Pred,Row],
    call(Call),
    N1 is N0+1,
    for_each_line(N1,N,A,Pred).

for_each_column(A,Pred):-
    functor(A,_,N),
    arg(1,A,Row1),
    functor(Row1,_,M),
    for_each_column(1,M,A,Pred).

for_each_column(N0,N,A,Pred):-N0>N,!.
for_each_column(N0,N,A,Pred):-
    array_column(N0,A,Column),
    Call=..[Pred,Column],
    call(Call),
    N1 is N0+1,
    for_each_column(N1,N,A,Pred).

for_each_diagonal(A,Pred):-
    for_each_diagonal_up(A,Pred),
    for_each_diagonal_down(A,Pred).

for_each_diagonal_up(A,Pred):-
    functor(A,_,N),
    arg(1,A,Row1),
    functor(Row1,_,M),
    (N=:=M->
     L is 2, U is N+N,
     for_each_diagonal_up(L,U,A,Pred);
     handle_exception(array_of_different_dimensions,(N,M))).

for_each_diagonal_down(A,Pred):-
    functor(A,_,N),
    arg(1,A,Row1),
    functor(Row1,_,M),
    (N=:=M->
     L is 1-N, U is N-1,
     for_each_diagonal_down(L,U,A,Pred);
     handle_exception(array_of_different_dimensions,(N,M))).

for_each_diagonal_up(K0,K,A,Pred):-K0>K,!.
for_each_diagonal_up(K0,K,A,Pred):-
    array_diagonal_up(K0,A,Diag),
    Call=..[Pred,Diag],
    call(Call),
    K1 is K0+1,
    for_each_diagonal_up(K1,K,A,Pred).

for_each_diagonal_down(K0,K,A,Pred):-K0>K,!.
for_each_diagonal_down(K0,K,A,Pred):-
    array_diagonal_down(K0,A,Diag),
    Call=..[Pred,Diag],
    call(Call),
    K1 is K0+1,
    for_each_diagonal_down(K1,K,A,Pred).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
my_array_to_list(A,List):-
    functor(A,_,N),
    arg(1,A,Row),
    functor(Row,_,M),
    array_to_list1(1,N,M,A,List).

array_to_list1(I0,I,M,A,List):-I0>I,!,List=[].
array_to_list1(I0,I,M,A,List):-
    arg(I0,A,Row),
    array_to_list2(1,M,Row,List,ListR),
    I1 is I0+1,
    array_to_list1(I1,I,M,A,ListR).

array_to_list2(J0,J,Row,List,ListR):-J0>J,!,List=ListR.
array_to_list2(J0,J,Row,List,ListR):-
    arg(J0,Row,Elm),
    List=[Elm|List1],
    J1 is J0+1,
    array_to_list2(J1,J,Row,List1,ListR).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
array_labeling(A):-
    my_array_to_list(A,List),
    labeling(List).

array_labeling_ff(A):-
    my_array_to_list(A,List),
    labeling_ff(List).

    


