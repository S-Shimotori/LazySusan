%   File   : queens.pl
%   Author : Neng-Fa ZHOU
%   Date   : 1998
%   Purpose: A linear-constraint program for solving the N-queens problem 


top:-
    N=96,
    top(N).

go:-
    write('N=?'),read(N),queens(N).

queens(N):-
    statistics(runtime,[Start|_]),
    top(N),
    statistics(runtime,[End|_]),
    T is End-Start,
    write('%execution time ='), write(T), write(' milliseconds'),nl.

top(N):-
    length(Qs,N),
    Qs :: 1..N,
    Qs1 @= [Qs[I]-I : I in 1..N],
    Qs2 @= [Qs[I]+I : I in 1..N],
    all_distinct(Qs),
    all_distinct(Qs1),
    all_distinct(Qs2),
    labeling([ff],Qs),
    write(Qs).

