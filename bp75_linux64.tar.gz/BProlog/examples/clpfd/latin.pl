/*
Problem posted by Jian Zhang (zj@ios.ac.cn)
Solution by Neng-Fa Zhou

Some definitions first:
A Latin square L of order n is an n X n table with each integer 0, 1, ...,
n-1
appearing exactly once in each row and each column. We call each of the n*n
positions of the table a cell. For instance, the position at row x column
y is
called cell (x; y) and the value of cell (x; y) is denoted as L(x; y),
where x; y; L(x; y) all take values from [0, n-1].
Two Latin squares L1 and L2 are orthogonal if and only if
L1(x1; y1) = L1(x2; y2) and L2(x1; y1) = L2(x2; y2) --> x1 = x2 and y1 = y2.

Roughly speaking, a latin square <--> quasigroup (QG).

A DSOLS of order n, denoted as DSOLS(n), is a Latin square A
which is orthogonal to both its transpose to the diagonal AT
and its transpose to the back diagonal A*.

Here is an example of DSOLS(4).

 0 2 3 1      0 3 1 2       3 0 2 1
 3 1 0 2      2 1 3 0       1 2 0 3
 1 3 2 0      3 0 2 1       0 3 1 2
 2 0 1 3      1 2 0 3       2 1 3 0

   A             AT           A*
*/

go:-
    dsols(4).

dsols(N):-
    new_array(A,[N,N]),
    Vars @= [A[I,J] : I in 1..N, J in 1..N],
    Vars :: 0..N-1,
    foreach(I in 1..N,[Row],(Row @= [A[I,J] : J in 1..N], all_distinct(Row))),
    foreach(J in 1..N,[Col],(Col @= [A[I,J] : I in 1..N], all_distinct(Col))),
    %
    new_array(AT,[N,N]),  % AT: transpose of A
    foreach(I in 1..N, J in 1..N, A[I,J] @=AT[J,I]),
    orthogonal(A,AT,N),	    
    %
    new_array(AB,[N,N]),  % AB: transpose to the back diagonal
    foreach(I in 1..N, J in 1..N, A[I,J] @= AB[N-J+1,N-I+1]),
    orthogonal(A,AB,N),
    %
    labeling_ff(Vars),
    format("~n  A~n"),
    foreach(I in 1..N, J in 1..N, [Aij], (Aij@=A[I,J],write(Aij),write(' '),(J==N->nl;true))),
    format("~n  AT~n"),
    foreach(I in 1..N, J in 1..N, [Aij], (Aij@=AT[I,J],write(Aij),write(' '),(J==N->nl;true))),
    format("~n  AB~n"),
    foreach(I in 1..N, J in 1..N, [Aij], (Aij@=AB[I,J],write(Aij),write(' '),(J==N->nl;true))).


% A and B are orthogonal
% for I1\=I2 or J1\=J2 if A[I1,J1]=A[I2,J2] -> B[I1,J1]\=B[I2,J2] and 
%                      if B[I1,J1]=B[I2,J2] -> A[I1,J1]\=A[I2,J2]
orthogonal(A,B,N):-
    foreach(I1 in 1..N, J1 in 1..N, I2 in 1..N, J2 in 1..N,
            ((I1\==I2;J1\==J2) ->
              A[I1,J1] #= A[I2,J2] #=> B[I1,J1] #\= B[I2,J2],
	      B[I1,J1] #= B[I2,J2] #=> A[I1,J1] #\= A[I2,J2]
	     ;
	     true)).

