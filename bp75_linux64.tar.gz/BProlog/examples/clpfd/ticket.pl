go:-
    [S,A]
