/* The leftmost switch (i = 1) toggles the states of the two leftmost bulbs (1 and 2); the rightmost switch (i = n) toggles the states of the two rightmost bulbs (n - 1 and n). Each remaining switch (1 < i < n) toggles the states of the three bulbs with indices i - 1, i, and i + 1. The minimum cost of changing a row of bulbs from an initial configuration to a final configuration is the minimum number of switches that must be flipped to achieve the change. For instance, 01100 represents a row of five bulbs in which the second and third bulbs are both ON. You could transform this state into 10000 by flipping switches 1, 4, and 5, but it would be less costly to simply flip switch 2. 
by Neng-Fa Zhou
*/
go:-
%    Initial=[0,1,1,0,0], Final=[1,0,0,0,0],
%    Initial=[1], Final=[1],
%    Initial=[1,1], Final=[0,0],
%    Initial=[1,1,1,1,0], Final=[0,0,1,0,1],
    Initial=[1,1,0,1,1,1,0,1,0,1,0,1,1,1,1,0,1,1,0,1,0,0,1,0,1,1,0,1,0,1,1,1,0],
    Final  =[0,0,0,0,0,0,0,0,0,0,1,1,0,1,0,1,1,0,1,1,0,0,1,0,1,0,1,1,0,1,0,0,0],
    plan0(Initial,Final,Plan),
    write(Plan),nl,
    fail.
go.
    

plan0([X],[X],Plan):-!,Plan=[0].
plan0([X],_,Plan):-!,Plan=[1].
plan0([X1,X2],[X1,X2],Plan):-!,Plan=[0].
plan0([X1,X2],_,Plan):-!,Plan=[1].
plan0(Initial,Final,Plan):-
    length(Initial,Len),
    length(Plan,Len),
    append(Initial,[0],NInitial), % add dummy bulbs
    append(Final,[_],NFinal),
    plan([0|NInitial],[_|NFinal],Plan).


:-table plan/3.
:-eager_consume plan/3.
plan([X1,X2,X3|Xs],[X1,Y2,Y3|Ys],[0|Plan]):-
    plan([X2,X3|Xs],[Y2,Y3|Ys],Plan).
plan([X1,X2,X3|Xs],[Y1,Y2,Y3|Ys],[1|Plan]):-
    opposite(X1,Y1),!,
    opposite(X2,OX2),
    opposite(X3,OX3),
    plan([OX2,OX3|Xs],[Y2,Y3|Ys],Plan).
plan([X1,X2],[X1,X2],[]). % the last two bulbs

opposite(0,1).
opposite(1,0).





