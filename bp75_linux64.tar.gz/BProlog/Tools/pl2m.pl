/* convert constraints in a CLP(FD) program partially into a Mercury style constraints */

pl2m(File):-
    see(File),
    read(Cl),
    pl2m_cl(Cl),
    seen.

pl2m_cl(end_of_file):-!.
pl2m_cl((H:-B)):-!,
    pl2m_body(B,B1),
    portray_clause((H:-B1)),
    read(NextCl),
    pl2m_cl(NextCl).
pl2m_cl(H):-
    portray_clause(H),
    read(NextCl),
    pl2m_cl(NextCl).

pl2m_body((G1;G2),(NG1;NG2)):-!,
    pl2m_body(G1,NG1),
    pl2m_body(G2,NG2).
pl2m_body((G1,G2),(NG1,NG2)):-!,
    pl2m_body(G1,NG1),
    pl2m_body(G2,NG2).
pl2m_body(Exp1#=Exp2,NG):-!,
    canonical_form_exp_cmp(1,Exp1-Exp2,0,Const,[],Coes,[],Vars),
    NG=linear_eq(Coes,Vars,Const).
pl2m_body(Exp1#>=Exp2,NG):-!,
    canonical_form_exp_cmp(1,Exp1-Exp2,0,Const,[],Coes,[],Vars),
    NG=linear_ge(Coes,Vars,Const).
pl2m_body(Exp1#=<Exp2,NG):-!,
    pl2m_body(Exp2#>=Exp1,NG).
pl2m_body(Exp1#>Exp2,NG):-!,
    pl2m_body(Exp1#>=Exp2+1,NG).
pl2m_body(Exp1#<Exp2,NG):-!,
    pl2m_body(Exp2#>Exp1,NG).
pl2m_body(G,G).
	  
