/* compare two binary files */
diff_bin(File1,File2):-
    NoByte is 1,
    readFile(File1,List1),
    readFile(File2,List2),
    diff_bin(List1,List2,NoByte).

diff_bin([],[],NoByte):-!.
diff_bin([],List2,NoByte):-
    format("~d ([],~w) ",[NoByte,List2]).
diff_bin(List1,[],NoByte):-
    format("~d (~w,[]) ",[NoByte,List1]).
diff_bin([X|List1],[Y|List2],NoByte):-
    (X==Y->true;
     format("~d (~d,~d) ",[NoByte,X,Y])),
    NoByte1 is NoByte+1,
    diff_bin(List1,List2,NoByte1).

    
