/* copy all the files from the directories to this directory */
go:- % unfold current working directory
    directory_files('.',Fs),
    copy_all([0'.],Fs).

unfold(Dir):-
    directory_files(Dir,Fs),
    atom_codes(Dir,Codes),
    copy_all(Codes,Fs).

copy_all(Pre,[]).
copy_all(Pre,['.'|Ds]):-!,
    copy_all(Pre,Ds).
copy_all(Pre,['..'|Ds]):-!,
    copy_all(Pre,Ds).
copy_all(Pre,[D|Ds]):-
    atom_codes(D,DCodes),
    append(Pre,[0'\|DCodes],Pre1),  % should be 0'/ for unix
    atom_codes(D1,Pre1),
    directory_exists(D1),!,
    directory_files(D1,Fs),
    copy_all(Pre1,Fs),
    copy_all(Pre,Ds).
copy_all(Pre,[D|Ds]):-
    atom_codes(D,DCodes),
    append(Pre,[0'\|DCodes],FCodes), % should be 0'/ for unix
    atom_codes(FName,FCodes),
    writeln(copy_file(FName,D)),
    copy_file(FName,D),
    copy_all(Pre,Ds).

    
    
    

    
